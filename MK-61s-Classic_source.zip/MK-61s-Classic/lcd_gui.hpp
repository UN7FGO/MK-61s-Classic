#ifndef LCD_FONT_PACK
#define LCD_FONT_PACK
#include  "Arduino.h"
#include  "config.h"
#include  "rust_types.h"
#include  "mk61emu_core.h"
#include  "ERM19264_UC1609.h"

extern ERM19264_UC1609 mylcd;

static const u8 GE                = 0x00;
static const u8 P_RUS             = 0x10;
static const u8 B_RUS             = 0x13;
static const u8 D_RUS             = 0x12;
static const u8 I_RUS             = 0x14;
static const u8 G_RUS             = 0x11;
static const u8 LCD_CHAR_POW2     = 0x15;
static const u8 LCD_CHAR_POWY     = 0x16;
static const u8 LCD_CHAR_XOR      = 0x17;

/* Стандартный набор символов из ПЗУ LCD */
static const u8 LCD_CYC_ARROW     = 0x05;
static const u8 LCD_DIVIDE_CHAR   = 0x08;
static const u8 LCD_NOT_EQU_CHAR  = 0x07;
static const u8 LCD_POW_X_CHAR    = 0x06;
static const u8 LCD_UP_ARROW_CHAR = 0x0B;
static const u8 LCD_LT_ARROW_CHAR = 0x0D;
static const u8 LCD_RT_ARROW_CHAR = 0x0C;
static const u8 LCD_PI_CHAR       = 0x0A;
static const u8 LCD_SQRT_CHAR     = 0x09;
static const u8 LCD_Em1_CHAR      = 0x18;
static const u8 LCD_GRAD_CHAR     = 0x0F;
static const u8 LCD_QUOTE_CHAR    = 0x60;
static const u8 LCD_DOUBLE_QUOTE_CHAR    = 0x22;
static const u8 CH_RUS            = 0x04;

class class_LCD_Label {
  private:
    u8 x, y;

  public:

    class_LCD_Label(u8 to_x, u8 to_y) : x(to_x), y(to_y) {}
    void print(const char* text) const {
      mylcd.setCursor(x*11, y*16);
      mylcd.print(F(text));
      mylcd.LCDupdate(); 
    }
    void print(char symbol) const {
      mylcd.setCursor(x*11, y*16);
      mylcd.print(symbol);
      mylcd.LCDupdate(); 
    }
    void print(int num) const {
      mylcd.setCursor(x*11, y*16);
      mylcd.print(F(num));
      mylcd.LCDupdate(); 
    }
    void print_hex(int num) const {
      mylcd.setCursor(x*11, y*16);
      if(num < 10) mylcd.print(' ');
      mylcd.print(F((num, HEX)));
      mylcd.LCDupdate(); 
    }
};

class LCD_GRD_Label {
  private:
    
    static constexpr u8 X = 6;
    static constexpr u8 Y = 0;

    const u32 ANGLE_UNIT_TEXT[3] = {
      0 << 24 | ' ' << 16   | ' ' << 8   |     'P',  // "Р  "
      0 << 24 | G_RUS << 16 | ' ' << 8   |     ' ',  // "  Г"
      0 << 24 | D_RUS << 16 | 'P' << 8   |   G_RUS   // "ГРД"
    };
    
    bool   on;

  public:

    LCD_GRD_Label(void) : on(true) {};

    void  disable(void) {
      on = false;
      mylcd.setCursor(X*11, Y*16);
      mylcd.print(' ');    // clear
      mylcd.LCDupdate(); 
    };

    void  enable(void)  {on = true;};

    void  print(AngleUnit angle) {
      if(on) {
        mylcd.setCursor(X*11, Y*16);
        mylcd.print((const char*) &ANGLE_UNIT_TEXT[angle - RADIAN]);
      }
      mylcd.LCDupdate(); 
    }

    void  print(const char* text) const {
      if(on) {
        mylcd.setCursor(X*11, Y*16);
        mylcd.print(F(text));
      }
      mylcd.LCDupdate(); 
    }

    void  print(char symbol) const {
      if(on) {
        mylcd.setCursor(X*11, Y*16);
        mylcd.print(symbol);
      }
      mylcd.LCDupdate(); 
    }

    void  print(int num) const {
      if(on) {
        mylcd.setCursor(X*11, Y*16);
        mylcd.print(F(num));
      }
      mylcd.LCDupdate(); 
   }

    void  print_hex(int num) const {
      if(on) {
        mylcd.setCursor(X*11, Y*16);
        if(num < 10) mylcd.print(' ');
        mylcd.print(F((num, HEX)));
      }
      mylcd.LCDupdate(); 
    }
};
#endif

#ifndef CONFIG
#define CONFIG

#include "Arduino.h"
#include "rust_types.h"

//#define DEBUG_CORE61
//#define DEBUG_MINI          // Отладочная информация по оболочке MK61S-MINI
//#define DEBUG_SPIFLASH      // Отладочная информация по обработке внешней флеш памяти
//#define DEBUG_DISASMBLER    // Отладочная информация по встроенному дисассемблеру МК61 инструкций
//#define DEBUG_KBD           // Отладочная информация по клавиатурному драйверу
//#define DEBUG_MENU          // Отладочная информация по системе меню
//#define DEBUG_LIBRARY       // Отладочная информация по библиотеке программ МК61
//#define DEBUG_MK61E         // Отладочная информация расширяющая представление вывода терминала по МК61
//#define EXPAND_RING_MK61    // Увеличить объем оперативной памяти кольца МК61 на еще один регистр IK130X
//#define MK61_EXTENDED
//#define B3_34
#define TERMINAL
#define SPI_FLASH
//#define DEBUG
//#define DEBUG_M61

//#define SERIAL_OUTPUT
#define MK61s

#if defined(MK61E) || defined(TERMINAL) || defined(DEBUG_CORE61) || defined(DEBUG_MENU) || defined(DEBUG_MINI) || defined(DEBUG) || defined(DEBUG_KBD) || defined(DEBUG_M61) || defined(DEBUG_DISASMBLER) || defined(DEBUG_LIBRARY) || defined(DEBUG_SPIFLASH)
 #define SERIAL_OUTPUT
 //#warning Serial module included!
#endif

#ifdef DEBUG_MINI
  constexpr bool DBG_MINI = true;
#else
  constexpr bool DBG_MINI = false;
#endif

#ifdef DEBUG_SPIFLASH
  constexpr bool DBG_SPIROM = true;
#else
  constexpr bool DBG_SPIROM = false;
#endif

#ifdef DEBUG_DISASMBLER
  constexpr bool DBG_DISASM = true;
#else
  constexpr bool DBG_DISASM = false;
#endif

#ifdef DEBUG_KBD
  constexpr bool DBG_KBD = true;
#else
  constexpr bool DBG_KBD = false;
#endif

#ifdef DEBUG_MENU
  constexpr bool DBG_MENU = true;
#else
  constexpr bool DBG_MENU = false;
#endif

#ifdef DEBUG_CORE61
  constexpr bool DBG_CORE61 = true;
#else
  constexpr bool DBG_CORE61 = false;
#endif

#ifdef DEBUG_LIBRARY
  constexpr bool DBG_LIB61 = true;
#else
  constexpr bool DBG_LIB61 = false;
#endif

#ifdef DEBUG_MK61E
  constexpr bool DBG_MK61E = true;
#else
  constexpr bool DBG_MK61E = false;
#endif

#ifdef ARDUINO_BLACKPILL_F411CE
  const char chip_name[] = "STM32F411CE";
  const char mem_text[] = "RAM:128 ROM:512";
#else
  #ifdef ARDUINO_BLACKPILL_F401CE
    const char chip_name[] = "STM32F401CE";
    const char mem_text[] = "RAM:96 ROM:512";
  #else
    #ifdef ARDUINO_BLACKPILL_F401CC
      const char chip_name[] = "STM32F401CC";
      const char mem_text[] = "RAM:64 ROM:256";
    #else
      #ifdef ARDUINO_GENERIC_F401CDUX
        const char chip_name[] = "STM32F401CD";
        const char mem_text[] = "RAM:96 ROM:384";
      #else
        #ifdef ARDUINO_GENERIC_F411CCUX
          const char chip_name[] = "STM32F411CC";
          const char mem_text[] = "RAM:128 ROM:256";
        #else
          #ifdef ARDUINO_GENERIC_F401CBYX
            const char chip_name[] = "STM32F401CB";
            const char mem_text[] = "RAM:64 ROM:128";
          #else
            const char chip_name[] = "unknown chip";
            const char mem_text[] = "unknown memory";
          #endif
        #endif
      #endif
    #endif
  #endif
#endif

#ifdef MK61s
      const char MODEL[] = "MK61s";
      //                       0123456789ABCDEF
      const char FULL_MODEL_NAME[] = "MK61s *firmware*";
  #else 
    #ifdef MK52s
      const char MODEL[] = "MK52s";
      const char FULL_MODEL_NAME[] = "MK52s *firmware*";
    #endif
#endif

#define FIRMWARE_VER (char const[]) {__TIME__[0], __TIME__[1],__TIME__[3],__TIME__[4],__TIME__[6],__TIME__[7],' ',__DATE__[0], __DATE__[1], __DATE__[2], __DATE__[3], (__DATE__[4] == ' ' ?  '0' : __DATE__[4]), __DATE__[5], __DATE__[6], __DATE__[9], __DATE__[10], __DATE__[11]}
class class_calc_config {
  public:
    bool disassm;
    bool output_IP;
    class_calc_config(void) : disassm(false), output_IP(false) {}
};

namespace cfg {

static constexpr isize  CLASSIC_MK61_QUANTS    =    72500;   // Константна замедления ядра mk61s в классичесокм режиме

}

// Конфигурация подключения микроконтроллера на макетной или печтаной плате 
 /* REVISION_V3 Описание ног для STM32F411CEU6 aka BlackPill MK61s-mini_v3*/
      static const u8   PIN_KBD_COL0    =   PB12;
      static const u8   PIN_KBD_COL1    =   PB13;
      static const u8   PIN_KBD_COL2    =   PB14;
      static const u8   PIN_KBD_COL3    =   PB15;
      static const u8   PIN_KBD_COL4    =   PA8;
      static const u8   PIN_KBD_COL5    =   PA9;
      static const u8   PIN_KBD_COL6    =   PA10;
      static const u8   PIN_KBD_COL7    =   PA15;
      static const u8   PIN_KBD_ROW4    =   PB8;
      static const u8   PIN_KBD_ROW3    =   PB7;
      static const u8   PIN_KBD_ROW2    =   PB6;
      static const u8   PIN_KBD_ROW1    =   PB5;
      static const u8   PIN_KBD_ROW0    =   PB4;
      static const u8   PIN_BUZZER      =   PA0;
      static const u8   PIN_SPIFLASH_CS =   PA4;
#endif
